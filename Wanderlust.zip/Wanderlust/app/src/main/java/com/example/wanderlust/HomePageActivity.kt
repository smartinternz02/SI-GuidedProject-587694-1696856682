package com.example.wanderlust

import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class HomePageActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home_page)

        val buttonHotels: Button = findViewById(R.id.buttonHotels)
        val buttonActivities: Button = findViewById(R.id.buttonActivities)

        buttonHotels.setOnClickListener {
            // Handle hotels button click
            // For simplicity, we'll just show a toast message
            showToast("Hotels clicked")
        }

        buttonActivities.setOnClickListener {
            // Handle activities button click
            // For simplicity, we'll just show a toast message
            showToast("Activities clicked")
        }
    }

    private fun showToast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }
}
